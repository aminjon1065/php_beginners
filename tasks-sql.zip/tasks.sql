-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Авг 09 2020 г., 11:15
-- Версия сервера: 5.6.47
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `tasks`
--

-- --------------------------------------------------------

--
-- Структура таблицы `taskeight`
--

CREATE TABLE `taskeight` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `taskeight`
--

INSERT INTO `taskeight` (`id`, `firstname`, `lastname`, `username`) VALUES
(1, 'Mark', 'Otto', '@mdo'),
(2, 'Jacob', 'Thornton', '@fat'),
(3, 'Larry', 'the Bird', '@twitter'),
(4, 'Larry the Bird', 'Bird', '@twitter'),
(14, 'Admin', 'Testov', '@UserName'),
(23, 'Test', 'Testov', '@test'),
(24, 'Test-2', 'Testov-2', '@UserName2');

-- --------------------------------------------------------

--
-- Структура таблицы `taskfive`
--

CREATE TABLE `taskfive` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `bootstrap` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `taskfive`
--

INSERT INTO `taskfive` (`id`, `name`, `profession`, `position`, `avatar`, `twitter`, `bootstrap`) VALUES
(1, 'Sunny A.', '(UI/UX Expert)', 'Lead Author', 'img/demo/authors/sunny.png', '@myplaneticket', 'myorange'),
(2, 'Jos K.', '(ASP.NET Developer)', 'Partner &amp; Contributor', 'img/demo/authors/josh.png', '@atlantez', 'Walapa'),
(3, 'Jovanni L.', '(PHP Developer)', 'Partner &amp; Contributor', 'img/demo/authors/jovanni.png', '@lodev09', 'lodev09'),
(4, 'Roberto R.', '(Rails Developer)', 'Partner &amp; Contributor', 'img/demo/authors/roberto.png', '@sildur', 'sildur');

-- --------------------------------------------------------

--
-- Структура таблицы `taskfour`
--

CREATE TABLE `taskfour` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `bg` varchar(255) NOT NULL,
  `width` varchar(255) NOT NULL,
  `valuenow` int(11) NOT NULL,
  `valuemin` int(11) NOT NULL,
  `valuemax` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `taskfour`
--

INSERT INTO `taskfour` (`id`, `title`, `value`, `bg`, `width`, `valuenow`, `valuemin`, `valuemax`) VALUES
(1, 'My Tasks', '130 / 500', 'bg-fusion-400', '65%', 65, 0, 100),
(2, 'Transfered', '440 TB', 'bg-success-500', '34%', 34, 0, 100),
(3, 'Bugs Squashed', '77%', 'bg-info-400', '77%', 77, 0, 100),
(4, 'User Testing', '7 days', 'bg-primary-300', '84%', 84, 0, 100);

-- --------------------------------------------------------

--
-- Структура таблицы `tasknine`
--

CREATE TABLE `tasknine` (
  `id` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `tasknine`
--

INSERT INTO `tasknine` (`id`, `text`) VALUES
(1, 'text'),
(2, 'text'),
(3, 'tesssttsststs'),
(4, 'tesssttsststs'),
(5, 'Том харди'),
(6, 'tesssttsststs'),
(7, 'loading'),
(8, 'loading2'),
(9, 'loading2'),
(10, 'loading'),
(11, 'tesssttsststs'),
(12, 'loading'),
(16, 'loading'),
(19, 'loading'),
(20, 'loading');

-- --------------------------------------------------------

--
-- Структура таблицы `taskone`
--

CREATE TABLE `taskone` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `tags` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `taskone`
--

INSERT INTO `taskone` (`id`, `title`, `tags`) VALUES
(1, 'Reports', 'reports file'),
(2, 'Analytics', 'analytics graphs'),
(3, 'Export', 'export download'),
(4, 'Storage', 'storage');

-- --------------------------------------------------------

--
-- Структура таблицы `tasksix`
--

CREATE TABLE `tasksix` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `profession` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `twitter` varchar(255) NOT NULL,
  `bootstrap` varchar(255) NOT NULL,
  `baned` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `tasksix`
--

INSERT INTO `tasksix` (`id`, `name`, `profession`, `position`, `avatar`, `twitter`, `bootstrap`, `baned`) VALUES
(1, 'Sunny A.', '(UI/UX Expert)', 'Lead Author', 'img/demo/authors/sunny.png', '@myplaneticket', 'myorange', 0),
(2, 'Jos K.', '(ASP.NET Developer)', 'Partner &amp; Contributor', 'img/demo/authors/josh.png', '@atlantez', 'Walapa', 0),
(3, 'Jovanni L.', '(PHP Developer)', 'Partner &amp; Contributor', 'img/demo/authors/jovanni.png', '@lodev09', 'lodev09', 1),
(4, 'Roberto R.', '(Rails Developer)', 'Partner &amp; Contributor', 'img/demo/authors/roberto.png', '@sildur', 'sildur', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `taskthree`
--

CREATE TABLE `taskthree` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `taskthree`
--

INSERT INTO `taskthree` (`id`, `name`, `href`, `active`) VALUES
(1, 'Главная', 'example.com/', 1),
(2, 'Функции', 'example.com/function', 1),
(3, 'PHP', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tasktwo`
--

CREATE TABLE `tasktwo` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `tasktwo`
--

INSERT INTO `tasktwo` (`id`, `title`, `description`) VALUES
(1, 'Privacy', 'Your privacy is important to us at SmartAdmin and the protection, confidentiality and integrity of your personal data are our prime concerns.\r\n         We will only use your personal information to administer your account, provide the products and services you have requested from us, and to keep you informed about our products and services (if you have consented to this).\r\n         We only use your data for the purposes for which it was collected and, where relevant, to meet local legal obligations.\r\n         We will retain your personal information only for as long as is necessary for the purposes for which the information was collected, or as long as is required pursuant to law.'),
(2, 'Cookies and other similar technologies', 'We collect certain data through cookies and similar technologies (e.g. web beacons, tags, device identifiers). Cookies are text files placed on your computer to collect standard internet log information and visitor behaviour information. This information is used to track visitor use of the website and to compile statistical reports on website activity. We register your interaction with our services in order to improve our website, content and services. Our use of such technologies and the data collected is described in more detail in our Cookie Policy. You can manage your cookie preferences through your browser settings.');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `taskeight`
--
ALTER TABLE `taskeight`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `taskfive`
--
ALTER TABLE `taskfive`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `taskfour`
--
ALTER TABLE `taskfour`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasknine`
--
ALTER TABLE `tasknine`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `taskone`
--
ALTER TABLE `taskone`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasksix`
--
ALTER TABLE `tasksix`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `taskthree`
--
ALTER TABLE `taskthree`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasktwo`
--
ALTER TABLE `tasktwo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `taskeight`
--
ALTER TABLE `taskeight`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `taskfive`
--
ALTER TABLE `taskfive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `taskfour`
--
ALTER TABLE `taskfour`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tasknine`
--
ALTER TABLE `tasknine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `taskone`
--
ALTER TABLE `taskone`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `tasksix`
--
ALTER TABLE `tasksix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `taskthree`
--
ALTER TABLE `taskthree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `tasktwo`
--
ALTER TABLE `tasktwo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
